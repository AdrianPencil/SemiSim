# semisim/physics/poisson.py
"""
1D nonlinear Poisson solver (MOS/MES/HEMT; variable ε, fixed + dynamic sheets).

Strong form (1D):
    d/dz( ε(z) dφ/dz ) = -ρ_vol(z) - Σ_j σ_j δ(z - z_j)

Finite-volume residual at node i (node-centered CV of size V_i):
    R_i = (F_{i+1/2} - F_{i-1/2})/V_i + ρ_vol,i + σ_i/V_i = 0
with face flux F_{i+1/2} = - ε_{i+1/2} [φ_{i+1} - φ_i] / Δz_{i+1/2}.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Optional

import numpy as np
from scipy.linalg import solve_banded

from ..utils.constants import Q, K_B, EPS0  # single source of truth
from ..geometry.builder import Geometry1D, MaterialFields
from .carriers.bands import BandParams, band_edges_from_potential
from .carriers.statistics import carriers_3d, derivatives_3d
from .interfaces import HEMT2DEGParams, hemt_2deg_sigma_and_jacobian

__all__ = [
    "PoissonBC",
    "PoissonSetup",
    "PoissonResult",
    "solve_poisson_1d",
]


# ----------------------------- Data containers ----------------------------- #
@dataclass(slots=True)
class PoissonBC:
    """Boundary conditions for 1D Poisson."""
    phi_s_V: float
    right: Literal["Dirichlet", "NeumannZero"] = "Dirichlet"
    phi_b_V: float = 0.0


@dataclass(slots=True)
class PoissonSetup:
    """Inputs to assemble and solve the nonlinear Poisson problem."""
    geom: Geometry1D
    mat: MaterialFields
    bands: BandParams
    bc: PoissonBC
    T_K: float
    mu_J: float
    stats: Literal["FD", "MB"] = "FD"
    gvc: float = 1.0
    gvv: float = 1.0
    ND_m3: Optional[np.ndarray] = None
    NA_m3: Optional[np.ndarray] = None
    rho_extra_Cm3: Optional[np.ndarray] = None
    # Fixed/interface sheets (e.g., polarization, fixed interface charge)
    sheet_nodes: Optional[np.ndarray] = None
    sheet_sigma_Cm2: Optional[np.ndarray] = None
    # HEMT 2DEG (dynamic sheet at interfaces; optional)
    hemt2deg: Optional[HEMT2DEGParams] = None
    # Nonlinear solve controls
    max_newton: int = 60
    tol_res_inf: float = 1e-7
    damping_init: float = 1.0
    exp_clip: float = 60.0
    phi_guess: Optional[np.ndarray] = None
    include_carriers: bool = True
    # Debug knobs
    debug: bool = False          # enable detailed prints
    debug_every: int = 1         # print every k iterations
    debug_idx: Optional[int] = None  # node to focus (e.g., interface index)


@dataclass(slots=True)
class PoissonResult:
    """Result container (float64, C-contiguous arrays)."""
    z: np.ndarray
    phi: np.ndarray
    n: np.ndarray
    p: np.ndarray
    E_C_J: np.ndarray
    E_V_J: np.ndarray
    resid: np.ndarray
    iters: int
    converged: bool

    def as_matrix(self) -> np.ndarray:
        return np.column_stack((self.z, self.phi, self.n, self.p, self.E_C_J, self.E_V_J))


# ----------------------------- Internal helpers ---------------------------- #
def _c64(x: np.ndarray | float) -> np.ndarray:
    return np.ascontiguousarray(x, dtype=np.float64)


def _nan_guard(name: str, *arrays: np.ndarray) -> None:
    """Fail fast on NaN/Inf to get a precise iteration location."""
    for i, arr in enumerate(arrays, 1):
        if not np.all(np.isfinite(arr)):
            raise FloatingPointError(f"NaN/Inf detected in {name}: array #{i}.")


def _warn_bad_mu(mu_J: float) -> None:
    """Soft guard to catch incorrect μ units (expects Joules ~1e-19 J)."""
    try:
        mu = float(mu_J)
        if mu != 0.0 and not (1e-22 < abs(mu) < 1e-17):
            print(f"[warn] mu_J looks wrong (J): {mu:.3e} (expected ~1e-19 J)")
    except Exception:
        print("[warn] mu_J not parseable as float — expected Joules ~1e-19 J.")

def _face_eps_harmonic_safe(eps_n: np.ndarray) -> np.ndarray:
    """
    ε_face = 2 εL εR / (εL + εR), robustly:
      - only divide where denom is finite and > 0
      - fall back to max(εL, εR) otherwise
      - floor tiny/non-positive values
    """
    epL = np.ascontiguousarray(eps_n[:-1], dtype=np.float64)
    epR = np.ascontiguousarray(eps_n[1:], dtype=np.float64)

    denom = epL + epR
    hm = np.empty_like(epL)

    mask = np.isfinite(denom) & (denom > 0.0)
    hm[~mask] = np.maximum(epL[~mask], epR[~mask])
    hm[mask] = (2.0 * epL[mask] * epR[mask]) / denom[mask]

    # Clean & floor
    hm = np.nan_to_num(hm, nan=np.maximum(epL, epR),
                       posinf=np.maximum(epL, epR), neginf=0.0)
    hm = np.where(hm <= 0.0, np.maximum(np.maximum(epL, epR), 1e-30), hm)
    return hm

def _make_dz_Vi_safe(z: np.ndarray, Vi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """
    Return (dz_face_safe, Vi_safe) with strictly positive, finite values.
    - dz_face_safe = diff(z), but any non-finite or ≤0 replaced by a tiny floor.
    - Vi_safe = original Vi where valid, otherwise rebuilt from z as CV sizes.
    """
    z = np.ascontiguousarray(z, dtype=np.float64)
    Vi_in = np.ascontiguousarray(Vi, dtype=np.float64)
    N = z.size
    if N < 2:
        raise ValueError("Geometry needs at least 2 nodes.")

    dz_raw = np.diff(z)  # (N-1,)
    mask_dz = np.isfinite(dz_raw) & (dz_raw > 0.0)
    dz_face = np.where(mask_dz, dz_raw, 1e-12)  # floor tiny/invalid to 1e-12 m

    # Build CV sizes from z if Vi invalid: Vi[0]=Δz_0/2, Vi[i]=0.5*(Δz_{i-1}+Δz_i), Vi[-1]=Δz_{N-2}/2
    Vi_from_z = np.empty(N, dtype=np.float64)
    Vi_from_z[0] = 0.5 * dz_face[0]
    Vi_from_z[-1] = 0.5 * dz_face[-1]
    if N > 2:
        Vi_from_z[1:-1] = 0.5 * (dz_face[:-1] + dz_face[1:])

    Vi_ok = np.isfinite(Vi_in) & (Vi_in > 0.0)
    Vi_safe = np.where(Vi_ok, Vi_in, Vi_from_z)
    Vi_safe = np.where(Vi_safe > 0.0, Vi_safe, 1e-18)  # final floor

    return dz_face, Vi_safe


# --------------------------------- Solver ---------------------------------- #

def solve_poisson_1d(setup: PoissonSetup) -> PoissonResult:
    """Nonlinear Newton solve for 1D Poisson (with optional dynamic 2DEG)."""
    _warn_bad_mu(setup.mu_J)
    z = _c64(setup.geom.z)
    Vi_in = _c64(setup.geom.Vi)
    eps_n = _c64(setup.mat.eps)
    dz_f, Vi = _make_dz_Vi_safe(z, Vi_in)
    N = z.size
    if N < 3: raise ValueError("Geometry must have at least 3 nodes.")
    if dz_f.size != N - 1: raise ValueError("geom.dz must have shape (N-1,) with face spacings.")
    eps_f = _c64(_face_eps_harmonic_safe(eps_n))
    ND = _c64(np.zeros(N) if setup.ND_m3 is None else setup.ND_m3)
    NA = _c64(np.zeros(N) if setup.NA_m3 is None else setup.NA_m3)
    rho_extra = _c64(np.zeros(N) if setup.rho_extra_Cm3 is None else setup.rho_extra_Cm3)
    ND, NA, rho_extra = np.nan_to_num(ND), np.nan_to_num(NA), np.nan_to_num(rho_extra)

    sigma_node = _c64(np.zeros(N))
    if setup.sheet_sigma_Cm2 is not None:
        sig = _c64(setup.sheet_sigma_Cm2)
        if setup.sheet_nodes is None:
            if sig.shape == (N,): sigma_node += sig
            else: raise ValueError("sheet_sigma_Cm2 provided without sheet_nodes must be length N.")
        else:
            idx = np.asarray(setup.sheet_nodes, dtype=np.int64)
            if idx.size != sig.size: raise ValueError("sheet_nodes and sheet_sigma_Cm2 length mismatch.")
            np.add.at(sigma_node, idx, sig)

    if setup.phi_guess is not None and setup.phi_guess.shape == z.shape:
        phi = _c64(setup.phi_guess.copy())
    else:
        phi = _c64(np.zeros_like(z))
    phi[0] = float(setup.bc.phi_s_V)
    if setup.bc.right == "Dirichlet":
        phi[-1] = float(setup.bc.phi_b_V)

    damping = float(setup.damping_init)
    converged = False
    resid = _c64(np.empty(N))
    it = 0
    a, b, c = np.zeros(N), np.zeros(N), np.zeros(N)
    V_T = float(K_B * setup.T_K / Q)
    alpha_f = _c64(eps_f / dz_f)

    for it in range(1, setup.max_newton + 1):
        if setup.include_carriers:
            E_C, E_V = band_edges_from_potential(phi, setup.bands)
            n, p = carriers_3d(E_C, E_V, setup.mu_J, setup.T_K, me_rel=setup.mat.me_dos_rel, mh_rel=setup.mat.mh_dos_rel, gvc=setup.gvc, gvv=setup.gvv, stats=setup.stats, exp_clip=setup.exp_clip)
            dn_dphi, dp_dphi, _, _ = derivatives_3d(E_C, E_V, setup.mu_J, setup.T_K, me_rel=setup.mat.me_dos_rel, mh_rel=setup.mat.mh_dos_rel, gvc=setup.gvc, gvv=setup.gvv, stats=setup.stats, exp_clip=setup.exp_clip)
        else:
            n, p, dn_dphi, dp_dphi = np.zeros(N), np.zeros(N), np.zeros(N), np.zeros(N)
            E_C, E_V = band_edges_from_potential(phi, setup.bands)

        _nan_guard("carriers", n, p)
        rho_vol = _c64(Q * (p - n + ND - NA) + rho_extra)
        F = _c64(-alpha_f * (phi[1:] - phi[:-1]))

        sigma2d, dsigma2d_dphi = np.zeros(N), np.zeros(N)
        if setup.hemt2deg is not None and setup.include_carriers:
            sigma2d, dsigma2d_dphi = hemt_2deg_sigma_and_jacobian(E_C, params=setup.hemt2deg, mu_J=setup.mu_J, T_K=setup.T_K, exp_clip=setup.exp_clip)
        sigma_total = _c64(sigma_node + sigma2d)

        resid.fill(0.0)
        divF = _c64((F[1:] - F[:-1]) / Vi[1:-1])
        resid[1:-1] = divF + rho_vol[1:-1] + sigma_total[1:-1] / Vi[1:-1]
        resid[0] = phi[0] - float(setup.bc.phi_s_V)
        if setup.bc.right == "Dirichlet":
            resid[-1] = phi[-1] - float(setup.bc.phi_b_V)
        else:
            resid[-1] = -F[-1] / Vi[-1] + rho_vol[-1] + sigma_total[-1] / Vi[-1]
        res_inf = float(np.linalg.norm(resid, ord=np.inf))

        if setup.debug and (it % max(1, setup.debug_every) == 0):
            print(f"  [iter {it:02d}] ||res||_inf={res_inf:.3e}, damping={damping:.2e} | φ∈[{phi.min():+.3e},{phi.max():+.3e}] V | n∈[{n.min():.3e},{n.max():.3e}] m^-3 | p∈[{p.min():.3e},{p.max():.3e}] m^-3")
        
        _nan_guard("residual", resid)
        if res_inf < setup.tol_res_inf:
            converged = True
            break

        # --- CORRECTED JACOBIAN ASSEMBLY ---
        a.fill(0.0); b.fill(0.0); c.fill(0.0)
        # Electrostatic part (always present)
        a[1:-1] = -alpha_f[:-1] / Vi[1:-1]
        c[1:-1] = -alpha_f[1:] / Vi[1:-1]
        b[1:-1] = (alpha_f[1:] + alpha_f[:-1]) / Vi[1:-1]
        
        # Dynamic charge part (only if carriers are included)
        if setup.include_carriers:
            b[1:-1] += Q * (dp_dphi[1:-1] - dn_dphi[1:-1])
            if setup.hemt2deg is not None:
                # Add the 2DEG derivative only at the specified nodes
                nodes_2deg = setup.hemt2deg.nodes
                b[nodes_2deg] += dsigma2d_dphi[nodes_2deg] / Vi[nodes_2deg]

        # Boundary rows
        b[0] = 1.0
        if setup.bc.right == "Dirichlet":
            b[-1] = 1.0
        else: # Neumann
            b[-1] = alpha_f[-1] / Vi[-1]
            a[-1] = -alpha_f[-1] / Vi[-1]
            if setup.include_carriers:
                b[-1] += Q * (dp_dphi[-1] - dn_dphi[-1])
                if setup.hemt2deg is not None and setup.hemt2deg.nodes[-1] == N - 1:
                     b[-1] += dsigma2d_dphi[-1] / Vi[-1]
        # --- END CORRECTION ---

        ab = np.vstack((np.roll(c, 1), b, np.roll(a, -1)))
        delta = solve_banded((1, 1), ab, -resid, overwrite_ab=True, check_finite=False)
        max_update = 10.0 * V_T
        delta = np.clip(delta, -max_update, +max_update)
        
        phi_trial = _c64(phi + damping * delta)
        # ... (rest of the line search and function is correct) ...
        E_C_t, E_V_t = band_edges_from_potential(phi_trial, setup.bands)
        if setup.include_carriers:
            n_t, p_t = carriers_3d(E_C_t, E_V_t, setup.mu_J, setup.T_K, me_rel=setup.mat.me_dos_rel, mh_rel=setup.mat.mh_dos_rel, gvc=setup.gvc, gvv=setup.gvv, stats=setup.stats, exp_clip=setup.exp_clip)
        else:
            n_t, p_t = np.zeros(N), np.zeros(N)

        rho_vol_t = _c64(Q * (p_t - n_t + ND - NA) + rho_extra)
        F_t = _c64(-alpha_f * (phi_trial[1:] - phi_trial[:-1]))
        sigma2d_t = np.zeros(N)
        if setup.hemt2deg is not None and setup.include_carriers:
            sigma2d_t, _ = hemt_2deg_sigma_and_jacobian(E_C_t, params=setup.hemt2deg, mu_J=setup.mu_J, T_K=setup.T_K, exp_clip=setup.exp_clip)
        sigma_total_t = _c64(sigma_node + sigma2d_t)
        resid_t = _c64(np.empty_like(resid))
        resid_t[1:-1] = (F_t[1:] - F_t[:-1]) / Vi[1:-1] + rho_vol_t[1:-1] + sigma_total_t[1:-1] / Vi[1:-1]
        resid_t[0] = phi_trial[0] - float(setup.bc.phi_s_V)
        if setup.bc.right == "Dirichlet":
            resid_t[-1] = phi_trial[-1] - float(setup.bc.phi_b_V)
        else:
            resid_t[-1] = -F_t[-1] / Vi[-1] + rho_vol_t[-1] + sigma_total_t[-1] / Vi[-1]
        res_inf_t = float(np.linalg.norm(resid_t, ord=np.inf))

        if res_inf_t < res_inf:
            phi = phi_trial
            resid = resid_t
            damping = min(1.0, damping * 1.25)
        else:
            damping *= 0.5
            if damping < 1e-12: 
                break

    E_C, E_V = band_edges_from_potential(phi, setup.bands)
    if setup.include_carriers:
        n, p = carriers_3d(E_C, E_V, setup.mu_J, setup.T_K, me_rel=setup.mat.me_dos_rel, mh_rel=setup.mat.mh_dos_rel, gvc=setup.gvc, gvv=setup.gvv, stats=setup.stats, exp_clip=setup.exp_clip)
    else:
        n, p = np.zeros(N), np.zeros(N)

    return PoissonResult(z=z, phi=phi, n=n, p=p, E_C_J=E_C, E_V_J=E_V, resid=resid, iters=it, converged=converged)