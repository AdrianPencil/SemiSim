# semisim/physics/polarization.py
"""
Polarization charge for wurtzite stacks (1D along c-axis).

Computes:
  - volumetric polarization charge:   rho_pol(z)  = - dPz/dz   [C/m^3]
  - interface sheet charge at z_i:    sigma_pol =  ΔPz|_i      [C/m^2]

where Pz = P_sp + P_pz and (for biaxial strain) e_zz ≈ -2 (c13/c33) e_xx.

This implementation is robust to missing fields: if a field is absent in MaterialFields,
it defaults to zeros (i.e., no polarization from that mechanism). It also accepts
either a structured interfaces array with fields ('z','left','right') or a plain Nx3 array.

Public API:
    PolarizationSetup
    PolarizationResult
    compute_polarization(setup)
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Literal, Tuple

import numpy as np

from ..geometry.builder import Geometry1D, MaterialFields

__all__ = ["PolarizationSetup", "PolarizationResult", "compute_polarization"]


@dataclass(slots=True)
class PolarizationSetup:
    geom: Geometry1D
    mat: MaterialFields
    eps_parallel: float = 0.0                   # reserved parameter (not used here)
    orientation: Literal["+c", "-c"] = "+c"     # sign of c-axis
    debug: bool = False


@dataclass(slots=True)
class PolarizationResult:
    sheet_nodes: np.ndarray        # (M,) int indices
    sigma_pol_Cm2: np.ndarray      # (N,) node-aligned sheet charge [C/m^2] (nonzero at interface nodes)
    rho_pol_Cm3: np.ndarray        # (N,) volumetric polarization charge [C/m^3]


# ------------------------------- helpers -------------------------------- #
def _c64(x) -> np.ndarray:
    return np.ascontiguousarray(x, dtype=np.float64)


def _zeros_like(x) -> np.ndarray:
    return np.zeros_like(_c64(x))


def _get_field(obj, name: str, default: np.ndarray) -> np.ndarray:
    """Return obj.name as float64 array if present, else default."""
    if hasattr(obj, name):
        return _c64(getattr(obj, name))
    return _c64(default)


def _parse_interfaces(interfaces) -> np.ndarray:
    """Return interfaces as float64 Nx3 array [z, left, right]."""
    if interfaces is None:
        return np.empty((0, 3), dtype=np.float64)

    arr = interfaces
    if isinstance(arr, np.ndarray) and arr.dtype.fields is not None:
        # Structured dtype with ('z','left','right')
        try:
            out = np.column_stack([arr["z"], arr["left"], arr["right"]]).astype(np.float64)
        except Exception as exc:
            raise TypeError("interfaces structured array must have fields ('z','left','right')") from exc
    else:
        out = np.asarray(arr, dtype=np.float64)
        if out.ndim == 1 and out.size % 3 == 0:
            out = out.reshape(-1, 3)

    if out.ndim != 2 or out.shape[1] != 3:
        raise ValueError("interfaces must be shape (N_ifaces, 3) with columns (z, left, right)")

    # force integer layer indices
    out[:, 1:] = np.round(out[:, 1:]).astype(np.int64)
    return out


def _safe_ratio(num: np.ndarray, den: np.ndarray) -> np.ndarray:
    """Compute num/den with masking to avoid divide by zero."""
    num = _c64(num)
    den = _c64(den)
    r = np.zeros_like(den)
    m = den != 0.0
    r[m] = num[m] / den[m]
    return np.nan_to_num(r, copy=False)


# ------------------------------- main API -------------------------------- #
def compute_polarization(setup: PolarizationSetup) -> PolarizationResult:
    """Compute polarization-induced volume and sheet charges for a 1D stack."""
    geom = setup.geom
    mat = setup.mat
    z = _c64(geom.z)
    N = z.size
    if N < 2:
        raise ValueError("Geometry must have at least 2 nodes for polarization computation.")

    sgn = +1.0 if setup.orientation == "+c" else -1.0
    Psp = _get_field(mat, "Psp_C_per_m2", np.zeros(N))
    e31 = _get_field(mat, "e31_C_per_m2", np.zeros(N))
    e33 = _get_field(mat, "e33_C_per_m2", np.zeros(N))
    c13 = _get_field(mat, "c13_Pa", np.zeros(N))
    c33 = _get_field(mat, "c33_Pa", np.ones(N))
    exx = _get_field(mat, "strain_xx", np.zeros(N))
    
    ezz = _get_field(mat, "strain_zz", None)
    if ezz is None:
        ezz = _c64(-2.0 * _safe_ratio(c13, c33) * exx)

    Ppz = _c64(2.0 * e31 * exx + e33 * ezz)
    Pz = _c64(sgn * (Psp + Ppz))
    
    rho_pol_Cm3 = _c64(-np.gradient(Pz, z))
    
    ifaces = _parse_interfaces(getattr(geom, "interfaces", None))
    sigma_pol_Cm2 = _c64(np.zeros(N))
    sheet_nodes: list[int] = []

    if ifaces.size > 0:
        for zif, left_layer_idx, right_layer_idx in ifaces:
            # --- CORRECTED LOGIC: Use nodes adjacent to the interface ---
            idx_iface = int(np.argmin(np.abs(z - zif)))
            # Find the last node of the left layer and first node of the right layer
            left_nodes = np.where(geom.layer_id == left_layer_idx)[0]
            right_nodes = np.where(geom.layer_id == right_layer_idx)[0]
            
            if left_nodes.size > 0 and right_nodes.size > 0:
                Pz_left = Pz[left_nodes[-1]]
                Pz_right = Pz[right_nodes[0]]
                dP = Pz_right - Pz_left
                sigma_pol_Cm2[idx_iface] += dP
                sheet_nodes.append(idx_iface)

    sheet_nodes = np.asarray(sorted(set(sheet_nodes)), dtype=int)
    np.nan_to_num(rho_pol_Cm3, copy=False)
    np.nan_to_num(sigma_pol_Cm2, copy=False)
    
    return PolarizationResult(
        sheet_nodes=sheet_nodes,
        sigma_pol_Cm2=sigma_pol_Cm2,
        rho_pol_Cm3=rho_pol_Cm3,
    )