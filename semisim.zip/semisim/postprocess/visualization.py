# lightweight plotting helpers (matplotlib only)
import numpy as np
import matplotlib.pyplot as plt

def band_diagram_fig(x, Ec, Ev, Efn=None, Efp=None, Ef0=None, annotate=True):
    fig, ax = plt.subplots()
    ax.plot(x, Ec, label="Ec")
    ax.plot(x, Ev, label="Ev")
    if Efn is not None: ax.plot(x, Efn, linestyle="--", label="E_Fn")
    if Efp is not None: ax.plot(x, Efp, linestyle="--", label="E_Fp")
    if Ef0 is not None: ax.axhline(Ef0, linestyle=":", label="E_F (eq)")
    if annotate:
        ax.set_xlabel("Position x [m]")
        ax.set_ylabel("Energy [J]")
        ax.legend()
        ax.set_title("Band diagram")
    fig.tight_layout()
    return fig

def iv_fig(V, I):
    fig, ax = plt.subplots(); ax.plot(V, I); ax.set_xlabel("V [V]"); ax.set_ylabel("I [A]"); ax.set_title("I–V")
    fig.tight_layout(); return fig

def cv_fig(Vg, C):
    fig, ax = plt.subplots(); ax.plot(Vg, C); ax.set_xlabel("Vg [V]"); ax.set_ylabel("C [F]"); ax.set_title("C–V")
    fig.tight_layout(); return fig

def field_fig(x, E):
    fig, ax = plt.subplots(); ax.plot(x, E); ax.set_xlabel("x [m]"); ax.set_ylabel("E-field [V/m]"); ax.set_title("Electric field")
    fig.tight_layout(); return fig

def thermal_fig(x, T):
    fig, ax = plt.subplots(); ax.plot(x, T); ax.set_xlabel("x [m]"); ax.set_ylabel("T [K]"); ax.set_title("Temperature")
    fig.tight_layout(); return fig
