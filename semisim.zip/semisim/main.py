# semisim/main.py
"""
Entry point for a 1D AlGaN/GaN HEMT band-diagram solve.

- Step 1: Poisson with fixed charges only (polarization, fixed sheets) to get a stable φ(z).
- Step 2: Self-consistent Poisson with FD carriers and dynamic 2DEG at the AlGaN/GaN interface.

Run:
    python -m semisim.main
"""
from __future__ import annotations

import numpy as np

from .utils.constants import Q
from .geometry.builder import (
    LayerSpec,
    CompositionSpec,
    StackSpec,
    MeshSpec,
    attach_stack,
    build_geometry,
    resolve_material_fields,
)
from .physics.polarization import PolarizationSetup, compute_polarization
from .physics.carriers.bands import build_band_params_from_fields, band_edges_from_potential
from .physics.interfaces import HEMT2DEGParams, hemt_2deg_sigma_and_jacobian
from .physics.poisson import PoissonBC, PoissonSetup, solve_poisson_1d
from semisim.physics.carriers.intrinsic import intrinsic_level_MB


# In semisim/main.py, replace the main() function

def main() -> None:
    # -------------------------- 1) Define stack --------------------------
    stack = StackSpec(
        layers=[
            LayerSpec(name="metal",  role="metal",         thickness=5e-9,   material="Al",  system=None),
            LayerSpec(name="AlGaN",  role="semiconductor", thickness=20e-9,  material="GaN", system="AlGaN",
                      comp=CompositionSpec(mode="constant", x0=0.25)),
            LayerSpec(name="GaN",    role="semiconductor", thickness=0.5e-6, material="GaN"),
            LayerSpec(name="buffer", role="semiconductor", thickness=2.0e-6, material="GaN"),
        ],
        T=300.0,
    )
    mesh = MeshSpec(per_layer_N=[10, 25, 50, 50])

    # Build geometry & material fields
    geom = build_geometry(stack, mesh)
    geom = attach_stack(geom, stack)
    mat = resolve_material_fields(geom)
    bands = build_band_params_from_fields(
        material=mat, layer_id=geom.layer_id, interfaces=geom.interfaces, model="affinity"
    )

    # -------------------- 2) Calculate All Fixed Charges ------------------
    pol = compute_polarization(
        PolarizationSetup(geom=geom, mat=mat, orientation="+c")
    )
    
    # --- [CRITICAL FIX] Directly use the full charge arrays from polarization ---
    rho_fixed = pol.rho_pol_Cm3      # Volumetric polarization charge
    sigma_fixed = pol.sigma_pol_Cm2  # FULL (N,) node-aligned sheet charge array

    # -------------------- 3) Set up HEMT & BCs ---------------------------
    # Find the main interface for the 2DEG (first semiconductor interface)
    ifaces = geom.interfaces
    if ifaces.size > 0:
        main_iface_z = ifaces['z'][0]
        idx_2deg = np.argmin(np.abs(geom.z - main_iface_z))
        hemt = HEMT2DEGParams(
            nodes=np.array([idx_2deg], dtype=int),
            Erel_J=[0.08 * Q], m2d_rel=mat.me_dos_rel[idx_2deg]
        )
    else:
        hemt, idx_2deg = None, None
        
    bc = PoissonBC(phi_s_V=0.0, right="Dirichlet", phi_b_V=0.0)

    # --------------------------- 4) Step 1 solve -------------------------
    print("--- Step 1/2: Solving for fixed charges (no mobile carriers) ---")
    step1_setup = PoissonSetup(
        geom=geom, mat=mat, bands=bands, bc=bc, T_K=stack.T,
        mu_J=0.0,
        rho_extra_Cm3=rho_fixed,
        # Pass the full sigma array and NO node list
        sheet_sigma_Cm2=sigma_fixed,
        sheet_nodes=None,
        include_carriers=False,
        debug=False
    )
    step1 = solve_poisson_1d(step1_setup)
    print(f"✅ Step 1 finished. Potential range: [{step1.phi.min():.3f}, {step1.phi.max():.3f}] V")

    # ------------------- 5) Calculate mu_J for Step 2 --------------------
    idx_sub = -1
    phi_sub = step1.phi[idx_sub]
    Ec_sub = bands.E_C0_J[idx_sub] - Q * phi_sub
    Ev_sub = bands.E_V0_J[idx_sub] - Q * phi_sub
    mu_J = intrinsic_level_MB(
        E_C_J=Ec_sub, E_V_J=Ev_sub, T=stack.T,
        me_rel=mat.me_dos_rel[idx_sub], mh_rel=mat.mh_dos_rel[idx_sub],
    )
    print(f"✅ Physical mu_J calculated for Step 2: {mu_J.item() / Q:.3f} eV")

    # --------------------------- 6) Step 2 solve -------------------------
    print("\n--- Step 2/2: Iterating to find self-consistent potential and carriers ---")
    step2_setup = PoissonSetup(
        geom=geom, mat=mat, bands=bands, bc=bc, T_K=stack.T,
        mu_J=mu_J,
        rho_extra_Cm3=rho_fixed,
        sheet_sigma_Cm2=sigma_fixed, # Use the same fixed charges
        sheet_nodes=None,
        hemt2deg=hemt,
        include_carriers=True,
        max_newton=80, tol_res_inf=1e-5,
        phi_guess=step1.phi,
        stats="FD", debug=True, debug_every=5,
        debug_idx=idx_2deg,
    )
    step2 = solve_poisson_1d(step2_setup)

    # ---------------------------- 7) Report ------------------------------
    print("\nSolved.")
    print(f"  Converged: {step2.converged} in {step2.iters} Newton iterations")
    print(f"  φ range: [{step2.phi.min():+.3e}, {step2.phi.max():+.3e}] V")
    print(f"  n max: {step2.n.max():.3e} m^-3, p max: {step2.p.max():.3e} m^-3")
    if hemt and idx_2deg is not None:
        # Calculate final 2DEG density from the dynamic sheet charge
        sigma_2deg, _ = hemt_2deg_sigma_and_jacobian(step2.E_C_J, params=hemt, mu_J=mu_J, T_K=stack.T)
        ns_2deg = -sigma_2deg[idx_2deg] / Q
        print(f"  2DEG interface node index: {idx_2deg}, Sheet Density ≈ {ns_2deg / 1e4:.3e} cm^-2")

if __name__ == "__main__":
    main()