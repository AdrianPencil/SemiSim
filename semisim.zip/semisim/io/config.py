# -*- coding: utf-8 -*-
"""
Load & validate YAML configs into a simple dict-like object.

Design:
  * Keep schema tolerant but explicit about required fields.
  * Support command-line overrides (key.path=value).
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import yaml

@dataclass
class RunConfig:
    raw: dict
    path: Path

def load_config(path: Path) -> RunConfig:
    with open(path, "r") as f:
        data = yaml.safe_load(f)
    _validate_minimum(data)
    return RunConfig(raw=data, path=path)

def apply_overrides(cfg: RunConfig, overrides: list[str]) -> RunConfig:
    for ov in overrides:
        key, val = ov.split("=", 1)
        _set_deep(cfg.raw, key.split("."), _coerce(val))
    return cfg

def _set_deep(d, keys, val):
    for k in keys[:-1]:
        d = d.setdefault(k, {})
    d[keys[-1]] = val

def _coerce(v: str):
    # very small coercer: int, float, bool, otherwise string
    if v.lower() in ("true", "false"):
        return v.lower() == "true"
    try:
        if "." in v: return float(v)
        return int(v)
    except ValueError:
        return v

def _validate_minimum(cfg: dict):
    required = ["geometry", "mesh", "physics", "solver", "outputs"]
    for r in required:
        if r not in cfg:
            raise ValueError(f"Missing top-level key: {r}")
