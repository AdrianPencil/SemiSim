# -*- coding: utf-8 -*-
"""
Layer stack CSV ingest.

Expected columns (example):
  name,material,thickness_nm,area_um2,TBR_m2K_per_W(optional)

Defaults:
  * TBR defaults to 0.0 if absent or blank (explicitly chosen).
Units:
  thickness [nm] → [m], area [um^2] → [m^2], TBR [m^2·K/W]
"""
from __future__ import annotations
import csv
from pathlib import Path
from typing import List
from semisim.models.layer import Layer

def load_layers(csv_path: Path) -> List[Layer]:
    layers: List[Layer] = []
    with open(csv_path, newline="") as f:
        for r in csv.DictReader(f):
            t_m = float(r['thickness_nm']) * 1e-9
            A_m2 = float(r['area_um2']) * 1e-12
            tbr = float(r.get('TBR_m2K_per_W', 0.0) or 0.0)
            layers.append(Layer(
                name=r['name'],
                material=r['material'],
                thickness_m=t_m,
                area_m2=A_m2,
                tbr_m2K_per_W=tbr
            ))
    return layers
